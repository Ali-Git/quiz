package com.quiz.contest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizcontestApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizcontestApplication.class, args);
	}

}

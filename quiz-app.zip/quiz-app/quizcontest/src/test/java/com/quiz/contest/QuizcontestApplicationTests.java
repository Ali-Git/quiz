package com.quiz.contest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizcontestApplicationTests {

	@Test
	void contextLoads() {
	}

}
